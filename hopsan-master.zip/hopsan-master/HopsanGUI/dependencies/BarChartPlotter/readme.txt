QSint is a opensource collection of Qt widgets which can be used while developing own Qt-based applications.

QSint is licensed as LGPL so you can use it both in commercial and non-commercial projects.

Copyright Sintegrial Technologies 2011

http://www.sintegrial.com
