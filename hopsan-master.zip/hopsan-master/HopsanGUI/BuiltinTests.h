#ifndef BUILTINTESTS_H
#define BUILTINTESTS_H

int runBuiltInTests();

#endif // BUILTINTESTS_H
