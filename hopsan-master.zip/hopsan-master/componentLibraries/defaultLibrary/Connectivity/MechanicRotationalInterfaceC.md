### Description
![MechanicRotationalInterfaceC picture](MechanicRotationalInterfaceC.svg)

Contains a rotational mechanical interface component of C-type

### Theory
This is a placeholder component for a rotational mechanical interface. It contains no equations and should normally only be used when exporting or connecting the model to external tools.
