### Description
![HydraulicInterfaceC picture](HydraulicInterfaceC.svg)

A hydraulic interface component of C-type

### Theory
This is a placeholder component for a hydraulic interface. It contains no equations and should normally only be used when exporting or connecting the model to external tools.
