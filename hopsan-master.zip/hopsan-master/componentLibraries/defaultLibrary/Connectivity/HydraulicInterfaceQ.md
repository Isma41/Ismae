### Description
![HydraulicInterfaceQ picture](HydraulicInterfaceQ.svg)

A hydraulic interface component of Q-type

### Theory
This is a placeholder component for a hydraulic interface. It contains no equations and should normally only be used when exporting or connecting the model to external tools.
