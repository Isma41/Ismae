Libraries that you put in this directory (as sub-directories) will be automatically loaded by HopsanGUI
