#ifndef MODEL_h
# define MODEL_h 
typedef struct {
    double HopsanRT_sine_Amp;
} Parameters;
#endif
