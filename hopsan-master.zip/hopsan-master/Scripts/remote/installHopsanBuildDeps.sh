#!/bin/bash

debs="subversion build-essential qt5-qmake qtbase5-dev  make unzip libtool automake pkg-config cmake"
sudo apt-get -y install $debs

