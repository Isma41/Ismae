The hopsan_rapidxml.hpp file is not part of rapid_xml it is a convenience include file for use in Hopsan created by the Hopsan developers
